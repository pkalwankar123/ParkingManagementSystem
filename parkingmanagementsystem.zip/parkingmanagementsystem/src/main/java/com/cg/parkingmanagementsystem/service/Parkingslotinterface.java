package com.cg.parkingmanagementsystem.service;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import com.cg.parkingmanagementsystem.dto.Parkingslot;
import com.cg.parkingmanagementsystem.exceptions.InvalidOwnerId;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsystem.exceptions.ParkingNotFoundException;

public interface Parkingslotinterface {
	public void createParkingslot(Parkingslot parkingslot) throws InvaliddetailId, InvalidOwnerId;
	public List<Parkingslot> searchByid(int id) throws ParkingNotFoundException, SQLException;
}

