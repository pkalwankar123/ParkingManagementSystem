package com.cg.parkingmanagementsys.dao;

import java.sql.SQLException;

import com.cg.parkingmanagementsys.dto.Parktransaction;
import com.cg.parkingmanagementsys.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsys.exceptions.invaliddetailexcepion;

public interface Parkingttransdaointerface {
	public Parktransaction book(Parktransaction park) throws invaliddetailexcepion, InvaliddetailId, SQLException;
}
