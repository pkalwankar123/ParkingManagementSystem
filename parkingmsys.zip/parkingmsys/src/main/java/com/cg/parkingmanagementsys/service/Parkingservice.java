package com.cg.parkingmanagementsys.service;

import com.cg.parkingmanagementsys.dao.Parkingdao;
import com.cg.parkingmanagementsys.dto.Parking;
import com.cg.parkingmanagementsys.exceptions.InvaliddetailId;

public class Parkingservice implements Parkingserviceinterface{

	
	Parkingdao parkdao;
	public Parkingservice(){
		parkdao=new Parkingdao();
	}
	
	
	public void addParking(Parking parking) throws InvaliddetailId {
		// TODO Auto-generated method stub
		parkdao.save(parking);
	}


}

