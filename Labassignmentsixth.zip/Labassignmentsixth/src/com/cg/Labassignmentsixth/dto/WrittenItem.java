package com.cg.Labassignmentsixth.dto;

import com.cg.Labassignmentsixth.ui.*;

public class WrittenItem extends Item{
	
	
	
	
	public String addBook;

	public String addDescr;

	public String addAuthor;
	
	public int addPrice;
	
	
	
	
	
	
		
		
	
		
	

	@Override
	public void removeBook() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addjournal() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removejournal() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addvideos() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removevideos() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addCd() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeCd() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addBook() {
		// TODO Auto-generated method stub
		
	}

	public String getAddBook() {
		return addBook;
	}

	public void setAddBook(String addBook) {
		this.addBook = addBook;
	}

	
public WrittenItem() {}
	
	public WrittenItem(String addBook, String addDescr, String addAuthor, int addPrice) {
		super();
		this.setAddBook(addBook);
		this.addDescr = addDescr;
		this.addAuthor = addAuthor;
		this.addPrice = addPrice;
		
	}
	
	@Override
	public void WrittenItem() {
		// TODO Auto-generated method stub
		
		//public void WrittenItem() {
			// TODO Auto-generated method stub
			
			
			
			addBook ad=new addBook();
			ad.addBook(addBook,addDescr,addAuthor,addPrice);
			
				
			}
		
	}
	


