package com.cg.Labassignmentsixth.ui;

import java.util.Scanner;

import com.cg.Labassignmentsixth.dto.*;

public class LabSixth {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int z;
		int i;
		
		WrittenItem wi[]=new WrittenItem[50];
		//WrittenItem wi[]=new WrittenItem[50];
		System.out.println("Library Management......");
		System.out.println("Library Admin");
		System.out.println("==================================================================");
		do {
			
		System.out.println("1. Book");
		System.out.println("2. journal articles");
		System.out.println("3. videos");
		System.out.println("4. CD's");
		System.out.println("5. Exit");
		Scanner sc=new Scanner(System.in);
		i=sc.nextInt();
		int j=0,k;
		
		
		switch(i) {
		case 1:
			do {
			
			System.out.println("1. New Arrival");
			System.out.println("2. Show all book");
			System.out.println("3. Back to Home");
			System.out.println("4. Exit");
			z=sc.nextInt();
			
			switch(z) {
			case 1:
				System.out.println("Add New book Name");
				String addBook=sc.next();
				System.out.println("Add Description");
				String addDescr=sc.next();
				System.out.println("Add Author");
				String addAuthor=sc.next();
				System.out.println("Add Price");
				int addPrice=sc.nextInt();
			
				wi[j]=new WrittenItem(addBook,addDescr,addAuthor,addPrice);
				
				
				
				
				
				
					break;
				
				
			case 2:
				for(int kk=0;kk<j;kk++) {
					wi[kk].WrittenItem();
				}
				System.out.println();
				//System.out.println("Java Fundamentals");
				//System.out.println(".Net");
				//System.out.println("String");
				
				int z1;
				
				System.out.println("1. Back to Home");
				System.out.println("2. Exit");
				z1=sc.nextInt();
				
				switch(z1) {
				case 1:
					break;
				case 2:
					
					System.out.println("Thanks you!!!");
					System.exit(0);
					break;
				default:
					System.out.println("Invalide choice, Please make sure your choice within the mentioned list");
					break;
			
				
				//break;
				
			}break;
			case 3:
				break;
			case 4:
				System.out.println("Thanks you!!!");
				System.exit(0);
				break;
			default:
				System.out.println("Invalide choice, Please make sure your choice within the mentioned list");
				break;
				}
			j++;
			}while(z<3);break;	
				
				
		/*		
		case 2:
				System.out.println("Java kathy Fundamentals");
				System.out.println(".Net");
				System.out.println("String");
				break;
			default:
				System.out.println("Invalide choice, Please make sure your choice within the mentioned list");
				break;
			
			
			
			
			break;
		default:
			System.out.println("Invalide choice, Please make sure your choice within the mentioned list");
			break;
			
		}
		*/
		//for x
			}}
			while(i<4);
				
		}	//wi.addBook();
		//System.out.println();
	}


