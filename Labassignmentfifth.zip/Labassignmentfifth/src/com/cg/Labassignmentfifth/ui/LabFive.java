package com.cg.Labassignmentfifth.ui;

public class LabFive {
	private int num;
	private int num1=0;
	
	
	public LabFive() {
		
	}
	
public LabFive(int num) {
	this.num=num;
		
	}

public boolean LabVoidPower(int nu) {
	if(nu%2==0) {
		int num1=nu/2;
num1=num1%2;
if(num1==0) {
return true;
	}
	}
	
	return false;

}
	
}
