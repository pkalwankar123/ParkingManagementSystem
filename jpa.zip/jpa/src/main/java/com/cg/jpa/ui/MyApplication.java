package com.cg.jpa.ui;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.jpa.dto.Address;
import com.cg.jpa.dto.Department;
import com.cg.jpa.dto.Employee;
import com.cg.jpa.service.Empservice;

public class MyApplication {

	/**
	 * @param args
	 */
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Empservice emps=new Empservice();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the emp id");
		
		int id=sc.nextInt();
System.out.println("Enter the emp name");
		
		String name=sc.next();
System.out.println("Enter the emp salary");
		
		double salary=sc.nextDouble();
		
System.out.println("Enter the emp date of joining");
		
		String date=sc.next();
System.out.println("Enter the dep id");
		
		int depid=sc.nextInt();
		
System.out.println("Enter the dep name");
		
		String depname=sc.next();
		
		
		Address add=new Address("Puneo","MH",455452);
		
		
		Department dep=new Department();
		dep.setDep_name(depname);
		dep.setId(depid);
		
		Employee emp=new Employee();
		
		emp.setId(id);
emp.setName(name);	
emp.setSal(salary);
emp.setAdd(add);
emp.setDateofjoining(new Date());
emp.setDep(dep);
		
		
		//emps.addEmployee(emp);
		//List<Employee> mylist=emps.searchBySalary(2000, 40000000);
List<Employee> mylist=emps.searchByDeaprtmentname(depname);		

for(Employee employee: mylist) {
			System.out.println("emp id: "+employee.getId());
			System.out.println("emp name: "+employee.getName());
			System.out.println("emp salary: "+employee.getSal());
			System.out.println("emp department: "+employee.getDep().getDep_name());
		}
		
		
		
		
		
		/*
		EntityManagerFactory em=Persistence.createEntityManagerFactory("demoemployee");
		
		EntityManager emf=em.createEntityManager();
		
		emf.getTransaction().begin();
		
		//Address add=new Address();
		//add.setCity("Pune");
		//add.setState("MH");
		//add.setPincode(411017);
		
		//add.setCity("Mumbai");
				//add.setState("MH");
				//add.setPincode(400088);
		
		//Employee emp=new Employee(405,"Pradip",250000.00,true,new Date(),add);
		
		//Scanner sc=new Scanner(System.in);
		//int id=sc.nextInt();
		
		
		Department dep=new Department();
		dep.setDep_name(".net");
		dep.setId(10);
		
		Department dep1=new Department();
		dep1.setDep_name("java");
		dep1.setId(20);
		
		Employee emp=new Employee(5,"Prad",25000000.00,true,new Date(),new Address("Puneo","MH",455452),dep);
		
		Employee emp1=new Employee(8,"dip23",35000000.00,true,new Date(),new Address("mumba","MH",400088),dep);
		
		Employee emp2=new Employee(9,"22",35000000.00,true,new Date(),new Address("mumba","MH",400088),dep1);	
		//List<Employee> list=new ArrayList<Employee>();
		//list.add(emp);
		//list.add(emp1);
		//list.add(emp2);
		//dep1.setMyemplist(list);
		dep.getMyemplist().add(emp);
		dep.getMyemplist().add(emp1);
	dep1.getMyemplist().add(emp2);
		
		
		
		
		//emf.persist(emp);
		//emf.persist(emp1);
		//emf.persist(emp2);
		
		emf.persist(dep);
		emf.persist(dep1);
		//emf.persist(dep1.getMyemplist().add(emp2));
		emf.getTransaction().commit();

		
		
		*/
		
	}

}
