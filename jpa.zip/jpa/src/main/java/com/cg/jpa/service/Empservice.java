package com.cg.jpa.service;

import java.util.List;

import com.cg.jpa.dao.EmpDaointerface;
import com.cg.jpa.dto.Employee;

public class Empservice implements Employeeservice{

	EmpDaointerface emp1;
	
	public Empservice() {
		emp1=new EmpDaointerface();
	}
	
	
	public void addEmployee(Employee emp) {
		
		emp1.save(emp);
	}

	public List<Employee> searchBySalary(double low, double higher) {

		return emp1.findBySalary(low, higher);
	}

	public List<Employee> searchByDeaprtmentname(String name) {

		return emp1.findByDeaprtmentname(name);
	}

}
