package com.cg.parkingmanagementsys.exceptions;

public class Duplicateaddressuserexception extends Exception {


	public Duplicateaddressuserexception() {
		
	}
	public Duplicateaddressuserexception(String msg) {
		super(msg);
	}
}

