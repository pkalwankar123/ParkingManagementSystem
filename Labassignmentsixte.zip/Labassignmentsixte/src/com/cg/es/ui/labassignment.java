package com.cg.es.ui;

import java.util.Scanner;

import com.cg.es.exception.EmployeeException;

public class labassignment {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter the salary of an Employee");
		double salary=sc.nextDouble();
		
		try{
			if(salary<3000) {
				throw new EmployeeException("Salary is less than 3000");
			}
			else {System.out.println("Salary is "+salary);}
			
		}catch(EmployeeException e) {
			System.out.println(e.getMessage());
		}
		
		

	}

}
