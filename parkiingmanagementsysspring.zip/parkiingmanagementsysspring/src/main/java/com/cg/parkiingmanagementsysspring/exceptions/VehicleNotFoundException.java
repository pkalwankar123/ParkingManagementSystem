package com.cg.parkiingmanagementsysspring.exceptions;

public class VehicleNotFoundException extends Exception {

	public VehicleNotFoundException(){}
	
	public VehicleNotFoundException(String exceptionMessage){
		super(exceptionMessage);
	}

	
}
