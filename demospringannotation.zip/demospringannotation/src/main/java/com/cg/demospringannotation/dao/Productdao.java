package com.cg.demospringannotation.dao;

import java.util.List;

import com.cg.demospringannotation.dto.Product;

public interface Productdao {
	public void save(Product prod);

	public List<Product> showAll();

	
	
}
