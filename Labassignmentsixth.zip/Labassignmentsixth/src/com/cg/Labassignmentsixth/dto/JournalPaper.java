package com.cg.Labassignmentsixth.dto;

public class JournalPaper {

}
