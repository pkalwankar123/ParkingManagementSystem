package com.cg.Labassignmentsixth.ui;

import com.cg.Labassignmentsixth.dto.WrittenItem;

public class addBook extends WrittenItem {
	//public String addBook, addDescr, addAuthor;
	//public int addPrice;
	


	
	
	public void addBook(String addBook,String addDescr,String addAuthor,int addPrice) {
		// TODO Auto-generated method stub
		
		System.out.println(addBook);
		System.out.println(addDescr);
		System.out.println(addAuthor);
		System.out.println(addPrice);
		System.out.println();
		
		
			
		}
	
	

}
