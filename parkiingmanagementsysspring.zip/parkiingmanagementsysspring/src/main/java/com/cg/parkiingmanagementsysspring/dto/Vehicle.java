package com.cg.parkiingmanagementsysspring.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("vehicle")
@Scope("prototype")
public class Vehicle {
	
	private String vehNo;
	private String vehDesc;
	@Autowired
	private Owner owner;
	


	public  Vehicle() {}

	public Vehicle(String vehNo, String vehDesc, Owner owner) {
		super();
		
		this.vehNo = vehNo;
		this.vehDesc = vehDesc;
		this.owner = owner;
	}

	
	



	


	public String getVehNo() {
		return vehNo;
	}


	public void setVehNo(String vehNo) {
		this.vehNo = vehNo;
	}


	public String getVehDesc() {
		return vehDesc;
	}


	public void setVehDesc(String vehDesc) {
		this.vehDesc = vehDesc;
	}


	public Owner getOwner() {
		return owner;
	}


	public void setOwner(Owner owner) {
		this.owner = owner;
	}

	public String vehicleDetails() {
		StringBuilder sb = new StringBuilder();
		//sb.append("Vehicle Id:- "+this.vehId);
		//sb.append(" ");
		sb.append("Vehicle Number:-"+this.vehNo);
		sb.append(" ");
		sb.append("Vehicle Description:-"+this.vehDesc);
		sb.append(" ");
		sb.append("Owner detail:-"+this.getOwner().ownerDetails());
		return sb.toString();	
	}
	

	

}