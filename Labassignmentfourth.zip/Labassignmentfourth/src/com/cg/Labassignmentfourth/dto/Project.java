package com.cg.Labassignmentfourth.dto;

public class Project {
	
	private int proAccN;
	private double proBal;
	
	
	public void methodus12(int proAcc,double proBal) {
		this.proAccN=proAcc;
		this.proBal=proBal;
		
	}


	@Override
	public String toString() {
		return "Project [proAccN=" + proAccN + ", proBal=" + proBal + "]";
	}
	

}
