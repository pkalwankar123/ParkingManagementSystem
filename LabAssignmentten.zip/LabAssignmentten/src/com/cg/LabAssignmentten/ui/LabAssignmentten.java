package com.cg.LabAssignmentten.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class LabAssignmentten {

	 public static void main(String[] args) throws IOException
	    {
		 Checked c1=new Checked();
	     
	      
	      System.out.print("Enter the Statement:");
	     
	     c1.getData();
	   }
}