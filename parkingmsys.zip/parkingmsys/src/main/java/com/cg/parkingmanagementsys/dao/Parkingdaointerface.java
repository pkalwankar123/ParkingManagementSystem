package com.cg.parkingmanagementsys.dao;

import com.cg.parkingmanagementsys.dto.Parking;
import com.cg.parkingmanagementsys.exceptions.InvaliddetailId;

public interface Parkingdaointerface {

	public Parking save(Parking park) throws InvaliddetailId;
	
}
