package com.cg.Labassignmentfourth.dto;

public class MethodAdd {
	
	
	private int useId;
	private String userName;
	private String userAdd;
	private Project proj;

	
	public void methodus(int id,String name, String Address) {
		this.useId=id;
		this.userName=name;
		this.userAdd=Address;
		
		
		
		
		
		
		
		
		
	}


	@Override
	public String toString() {
		return "Last updated USER useId=" + useId + ", userName=" + userName + ", userAdd=" + userAdd;
	}

	
}
