package com.cg.Labassignmentone.dto;

public class Firstlab {
	
	public int calculateSum;
	int sum=0;
	
	
	public int calculateSum(int n) {
		
		
		for(int j=0;j<=n;j++) {
			
			if(n>0) {
				if(j%3==0 || j%5==0) {
					//System.out.println("natural numbers of user entered values"+j);
					sum +=j;
					
				}
				
				
				
			}
			else {
				System.out.println("Please enter the Natural number starting from 1 and so on....");
				
			}
		
	}
		return sum;

}


	@Override
	public String toString() {
		return "sum of n natural numbers=" + sum ;
	}
}