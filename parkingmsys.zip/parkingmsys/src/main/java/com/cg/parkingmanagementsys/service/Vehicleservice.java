package com.cg.parkingmanagementsys.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.parkingmanagementsys.dto.Vehicle;
import com.cg.parkingmanagementsys.exception.InvalidOwnerId;
import com.cg.parkingmanagementsys.exception.InvaliddetailId;
import com.cg.parkingmanagementsys.exceptions.VehicleNotFoundException;


public interface Vehicleservice {


	public void add(Vehicle vehicle) throws  InvaliddetailId, SQLException;
	public List<Vehicle> searchbyVehNo(String vehNo) throws VehicleNotFoundException, SQLException;

}
