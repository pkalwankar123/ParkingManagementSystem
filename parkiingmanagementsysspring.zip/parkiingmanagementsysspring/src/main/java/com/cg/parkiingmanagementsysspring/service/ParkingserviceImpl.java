package com.cg.parkiingmanagementsysspring.service;


import org.springframework.stereotype.Service;

import com.cg.parkiingmanagementsysspring.dao.ParkingrepositoryImpl;
import com.cg.parkiingmanagementsysspring.dto.Parking;

@Service("parkingService")
public class ParkingserviceImpl implements Parkingserviceinterface{

	
	ParkingrepositoryImpl parkRepository;
	public ParkingserviceImpl(){
		parkRepository=new ParkingrepositoryImpl();
	}
	
	

	public void addParking(Parking parking) {

		parkRepository.save(parking);
	}

}

