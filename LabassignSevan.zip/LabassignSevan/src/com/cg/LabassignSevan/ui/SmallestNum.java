package com.cg.LabassignSevan.ui;

public class SmallestNum {
	
	int i,d,swap=0;
private int[] num;

public void getsmallData(int[] a) {
	
	 for (i = 0; i < ( a.length ); i++) {
	      for (d = 0; d < a.length - i - 1; d++) {
	        if (a[d] > a[d+1]) 
	        {
	          swap       = a[d];
	          a[d]   = a[d+1];
	          a[d+1] = swap;
	        }
	      }
	    }
	
	
	
	//System.out.println(a);
}
	
}
