package com.cg.springmvcdemoone.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.springmvcdemoone.dto.Product;
@Repository("productDao")
public class ProductdaoImpl implements Productdaointerface {

	List<Product> myList=new ArrayList<>();
	
	@Override
	public Product save(Product product) {
		// TODO Auto-generated method stub
		myList.add(product);
		return product;
	}

	@Override
	public List<Product> show() {
		// TODO Auto-generated method stub
		return myList;
	}

}
