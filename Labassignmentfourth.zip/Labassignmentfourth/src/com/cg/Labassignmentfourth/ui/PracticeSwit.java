package com.cg.Labassignmentfourth.ui;

import java.util.Scanner;

import com.cg.Labassignmentfourth.dto.*;



public class PracticeSwit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodAdd met=new MethodAdd();
		Project proj=new Project();
		int ch1;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Please select an option from below choices");
	
	do{	
		
		System.out.println("1. Add");
		System.out.println("2. Exit");
		ch1=sc.nextInt();
		
		
		switch(ch1) {
		case 1:
			
			
			
			
			
			System.out.println("Please enter the UserID"+"\t");
			int ch2=sc.nextInt();
			System.out.println("Please enter the UserName"+"\t");
			String ch3=sc.next();
			System.out.println("Please enter the UserAdd"+"\t");
			String ch4=sc.next();
			System.out.println("Please enter the Account No"+"\t");
			int ch5=sc.nextInt();
			System.out.println("Please enter the Account Bal"+"\t");
			int ch6=sc.nextInt();
			
			
			
			met.methodus(ch2, ch3, ch4);
			proj.methodus12(ch5, ch6);
			
			System.out.println(met);
			System.out.println(proj);
			
			break;
		case 2:
			System.out.println("thanks you!!! EXIT!!!!");
			
			break;
			
		
		default:
			System.out.println("invalid choice value");
			break;
		}
		
	}while(ch1<2);

	
	}

}
