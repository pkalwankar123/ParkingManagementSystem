package com.cg.parkiingmanagementsysspring.dto;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


@Component("parkingtransaction")
@Scope("prototype")
	public class Parktransaction {
		private int id;
		@Autowired
		private Parkingslot pk;
		@Autowired
		private Vehicle veh;
		private LocalDate startDate;
		private LocalDate endDate;
		
		private LocalTime startTime;
		
		private LocalTime endTime;

		public Parktransaction() {}

		public Parktransaction(int id, Parkingslot pk, Vehicle veh, LocalDate startDate, LocalDate endDate,
				LocalTime startTime, LocalTime endTime) {
			super();
			this.id = id;
			this.pk = pk;
			this.veh = veh;
			this.startDate = startDate;
			this.endDate = endDate;
			this.startTime = startTime;
			this.endTime = endTime;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public Parkingslot getPk() {
			return pk;
		}

		public void setPk(Parkingslot pk) {
			this.pk = pk;
		}

		public Vehicle getVeh() {
			return veh;
		}

		public void setVeh(Vehicle veh) {
			this.veh = veh;
		}

		public LocalDate getStartDate() {
			return startDate;
		}

		public void setStartDate(LocalDate startDate) {
			this.startDate = startDate;
		}

		public LocalDate getEndDate() {
			return endDate;
		}

		public void setEndDate(LocalDate endDate) {
			this.endDate = endDate;
		}

		public LocalTime getStartTime() {
			return startTime;
		}

		public void setStartTime(LocalTime startTime) {
			this.startTime = startTime;
		}

		public LocalTime getEndTime() {
			return endTime;
		}

		public void setEndTime(LocalTime endTime) {
			this.endTime = endTime;
		}

		@Override
		public String toString() {
			return "Parktransaction [id=" + id + ", pk=" + pk + ", veh=" + veh + ", startDate=" + startDate + ", endDate="
					+ endDate + ", startTime=" + startTime + ", endTime=" + endTime + "]";
		}

		
	
	}

