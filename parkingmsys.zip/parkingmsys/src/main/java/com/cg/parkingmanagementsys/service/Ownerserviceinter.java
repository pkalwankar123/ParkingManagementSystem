package com.cg.parkingmanagementsys.service;

import java.sql.SQLException;

import com.cg.parkingmanagementsys.dto.Owner;
import com.cg.parkingmanagementsys.exception.duplicateaddressuserexception;
import com.cg.parkingmanagementsys.exceptions.Duplicateaddressuserexception;

public interface Ownerserviceinter {
public Owner add(Owner owe) throws Duplicateaddressuserexception, SQLException;
}
