package com.cg.parkingmanagementsystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.persistence.EntityManager;

import com.cg.parkingmanagementsystem.dbutil.Dbutil;
import com.cg.parkingmanagementsystem.dto.Owner;
import com.cg.parkingmanagementsystem.exceptions.Duplicateaddressuserexception;


public class Ownerrepository implements Ownerrepositoryinterface{

	
	EntityManager em;
	public Ownerrepository() {
		em=Dbutil.em;
	}
	
	public Owner save(Owner owner) throws Duplicateaddressuserexception, SQLException {
		em.getTransaction().begin();
		em.persist(owner);

		em.getTransaction().commit();
		em.close();
		return null;
	}
	

}
