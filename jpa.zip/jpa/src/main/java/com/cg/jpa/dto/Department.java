package com.cg.jpa.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Department {
	@Id
	@Column(name="dep_id")
	private int id;
	@Column(name="dep_name")
	private String dep_name;
	
	
	@OneToMany(cascade=CascadeType.ALL,mappedBy  = "dep" )
	private List<Employee> myemplist=new ArrayList<Employee>();
	
	public Department() {}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDep_name() {
		return dep_name;
	}

	public void setDep_name(String dep_name) {
		this.dep_name = dep_name;
	}

	
	

	public Department(int id, String dep_name, List<Employee> myemplist) {
		super();
		this.id = id;
		this.dep_name = dep_name;
		this.myemplist = myemplist;
	}

	public List<Employee> getMyemplist() {
		return myemplist;
	}

	public void setMyemplist(List<Employee> myemplist) {
		this.myemplist = myemplist;
	}

	@Override
	public String toString() {
		return "Department [id=" + id + ", dep_name=" + dep_name + ", myemplist=" + myemplist + "]";
	}
	
	
	

}
