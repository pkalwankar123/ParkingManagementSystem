package com.cg.parkingmanagementsys.service;

import java.sql.SQLException;

import com.cg.parkingmanagementsys.dao.Parktransdao;
import com.cg.parkingmanagementsys.dto.Parktransaction;
import com.cg.parkingmanagementsys.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsys.exceptions.invaliddetailexcepion;

public class Parkingtransservice implements Parkingtransserivceinterface{
Parktransdao parktrans;
	
	public Parkingtransservice(){
		parktrans=new Parktransdao();
	}
	
	public void bookParking(Parktransaction parktrans1) throws invaliddetailexcepion, InvaliddetailId, SQLException{
		
		
		parktrans.book(parktrans1);
	}


}
