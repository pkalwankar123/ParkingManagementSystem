package com.cg.jpa.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Dbutil {
	
	static EntityManager em=null;
	public static EntityManager getConnection() {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("demoemployee");
		
		em=entityManagerFactory.createEntityManager();
		em.getTransaction().begin();
		return em;
	}
	

}
