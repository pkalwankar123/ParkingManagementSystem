package com.cg.parkiingmanagementsysspring.service;


import com.cg.parkiingmanagementsysspring.dto.Parktransaction;
import com.cg.parkiingmanagementsysspring.exceptions.invaliddetailexcepion;

public class Parkingtransservice implements Parkingtransserivceinterface{
	Parktransdao parktrans;
	
	public Parkingtransservice(){
		parktrans=new Parktransdao();
	}

	public void bookParking(Parktransaction parktrans1) throws invaliddetailexcepion{
		
		
		parktrans.book(parktrans1);
	}

}
