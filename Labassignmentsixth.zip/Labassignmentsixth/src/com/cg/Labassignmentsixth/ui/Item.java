package com.cg.Labassignmentsixth.ui;

public abstract class Item {
	public String addBook;

	public String addDescr;

	public String addAuthor;
	
	public int addPrice;
	private int idNum;
	private String bookTitle;
	private int numCoppies;
	public abstract void addBook();
	public abstract void removeBook();
	public abstract void addjournal();
	public abstract void removejournal();
	public abstract void addvideos();
	public abstract void removevideos();
	public abstract void addCd();
	public abstract void removeCd();
	public void WrittenItem(String addBook,String addDescr,String addAuthor,int addPrice) {
		
		
	}
		// TODO Auto-generated method stub
	public void WrittenItem() {
		// TODO Auto-generated method stub
		
	}
		
	
	

}
