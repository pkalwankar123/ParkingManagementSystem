package com.cg.Labassignmentfourteen.ui;

public class firstlastnameexception extends Exception {
public firstlastnameexception() {}

public firstlastnameexception(String msg) {
	super(msg);
}
	
	
}
