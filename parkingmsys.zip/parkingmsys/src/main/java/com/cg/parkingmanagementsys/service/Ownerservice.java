package com.cg.parkingmanagementsys.service;

import java.sql.SQLException;

import com.cg.parkingmanagementsys.dao.Ownerdao;
import com.cg.parkingmanagementsys.dto.Owner;
import com.cg.parkingmanagementsys.exception.duplicateaddressuserexception;
import com.cg.parkingmanagementsys.exceptions.Duplicateaddressuserexception;

public class Ownerservice implements Ownerserviceinter{
	Ownerdao owed;
	public Ownerservice() {
	owed=new Ownerdao();	
	}
	public Owner add(Owner owe) throws Duplicateaddressuserexception, SQLException {
		
		return owed.save(owe);
	}
	
	
}
