package com.cg.demospringannotation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cg.demospringannotation.dao.Productdao;
import com.cg.demospringannotation.dao.Productdaoimp;
import com.cg.demospringannotation.dto.Product;

@Component("productservice")
public class ProductserviceImp implements Productservice {

	//@Autowired
	//Productdaoimp productdao;
	Productdao productdao;
	@Autowired
	public ProductserviceImp(Productdaoimp productdao) {
		
		this.productdao = productdao;
	}

	public void addProduct(Product prod) {

		productdao.save(prod);
	}

	public List<Product> showAll() {

		return productdao.showAll();
	}

}
