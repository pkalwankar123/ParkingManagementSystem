package com.cg.parkingmanagementsys.dto;

public class Address {
	
	//Attributes//
	
	private String houseNo;
	private int addid;
	private String Street;
	private String city;
	private int pincode;
	//Attributes//
	
	//Constructors//
	public Address() {}
	
	
public Address(int addid,String houseNo, String street, String city, int pincode) {
		super();
		this.addid=addid;
		this.houseNo = houseNo;
		Street = street;
		this.city = city;
		this.pincode = pincode;
	}
//Constructors//

//Getter and setters//

public int getAddid() {
	return addid;
}
public void setAddid(int addid) {
	this.addid = addid;
}
public String getHouseNo() {
	return houseNo;
}
public void setHouseNo(String houseNo) {
	this.houseNo = houseNo;
}
public String getStreet() {
	return Street;
}
public void setStreet(String street) {
	Street = street;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public int getPincode() {
	return pincode;
}
public void setPincode(int pincode) {
	this.pincode = pincode;
}


//Tostring method//
@Override
public String toString() {
	return "Address [houseNo=" + houseNo + ", addid=" + addid + ", Street=" + Street + ", city=" + city + ", pincode="
			+ pincode + "]";
}




}
