package com.cg.parkingmanagementsys.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.parkingmanagementsys.dto.Owner;
import com.cg.parkingmanagementsys.exception.duplicateaddressuserexception;
import com.cg.parkingmanagementsys.exceptions.Duplicateaddressuserexception;
import com.cg.parkingmanagementsys.util.DButil;

public class Ownerdao implements Ownerdaointerface{
	static Connection con;
	public Owner save(Owner owe) throws Duplicateaddressuserexception, SQLException {
		con=DButil.getConnection();
	String query_insert="Insert into address(addid,houseno,street,city,pincode) values(?,?,?,?,?)";
	String query_insertone="Insert into owner(id,name,mobno,addid) values(?,?,?,?)";
	String query="Select addid from address where addid=?";
	String queryOne="Select id from owner where id=?";
	PreparedStatement pstm=null;
	PreparedStatement pstmone=null;
	PreparedStatement pstmtwo=null;
	PreparedStatement pstmthree=null;
	try {

		pstmthree=con.prepareStatement(queryOne);
		pstmthree.setInt(1, owe.getId());
		ResultSet rs1=pstmthree.executeQuery();
		
			pstmtwo=con.prepareStatement(query);
			pstmtwo.setInt(1, owe.getAddress().getAddid());
			ResultSet rs=pstmtwo.executeQuery();
		
		if(rs1.next()==false){
			if(rs.next()==false) {	
		
		pstm=con.prepareStatement(query_insertone);
		 pstm.setInt(1, owe.getId());
		 pstm.setString(2, owe.getName());
		 pstm.setString(3, owe.getMobNo().toString());
	
		 pstm.setInt(4, owe.getAddress().getAddid());
		 
	pstm.executeUpdate();
	pstmone=con.prepareStatement(query_insert);
	pstmone.setInt(1, owe.getAddress().getAddid());
	pstmone.setString(2, owe.getAddress().getHouseNo());
	pstmone.setString(3, owe.getAddress().getStreet());
	pstmone.setString(4, owe.getAddress().getCity());
	pstmone.setInt(5, owe.getAddress().getPincode());
	
	pstmone.executeUpdate();
	}


else {
	throw new Duplicateaddressuserexception("OOPs, this Id is presnt into the database, Kindly use the new Address ID");  

		
}	}else {
	throw new Duplicateaddressuserexception("OOPs, this Id is presnt into the database, Kindly use the new  Owner ID!!!");  

		
}	

	}
catch(SQLException e) {
	e.printStackTrace();
		
	}
return owe;	
	
}

}
