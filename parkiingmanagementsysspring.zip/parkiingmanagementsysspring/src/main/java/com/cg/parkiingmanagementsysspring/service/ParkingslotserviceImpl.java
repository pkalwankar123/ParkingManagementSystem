package com.cg.parkiingmanagementsysspring.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.parkiingmanagementsysspring.dao.ParkingslotrepositoryImpl;
import com.cg.parkiingmanagementsysspring.dto.Parkingslot;

@Service("parkingslotService")
public class ParkingslotserviceImpl implements Parkingslotinterface{

	ParkingslotrepositoryImpl parkslot;
	

	
	

@Autowired
	public void setParkslot(ParkingslotrepositoryImpl parkslot) {
		this.parkslot = parkslot;
	}


	public void createParkingslot(Parkingslot parkingslot) {

		parkslot.create(parkingslot);
	}


	public Parkingslot searchbydate(Date date) {

		return null;
	}

}

