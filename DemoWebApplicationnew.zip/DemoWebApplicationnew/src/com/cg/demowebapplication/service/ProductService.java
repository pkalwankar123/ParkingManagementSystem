package com.cg.demowebapplication.service;

import java.util.List;

import com.cg.demowebapplication.dto.Product;

public interface ProductService {
	public void addproduct(Product prod);

	public List<Product> showProduct();

	public Product searchById(int id);

	public Product updateProduct(Product prod);

	public void deleteProduct(Product prod);

}
