package com.cg.Demoonespringcore.dto;

public class Item {
private int id;



public Item() {}

public Item(int id, String nameOfShop) {
	super();
	this.id = id;
	this.nameOfShop = nameOfShop;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getNameOfShop() {
	return nameOfShop;
}

public void setNameOfShop(String nameOfShop) {
	this.nameOfShop = nameOfShop;
}

private String nameOfShop;
	
	
	@Override
public String toString() {
	return "Item [id=" + id + ", nameOfShop=" + nameOfShop + "]";
}

	public void getAllItemData() {
		System.out.println("In Items");
	}
	
}
