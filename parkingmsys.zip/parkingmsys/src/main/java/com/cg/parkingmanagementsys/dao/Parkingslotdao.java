package com.cg.parkingmanagementsys.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.parkingmanagementsys.dto.Parkingslot;
import com.cg.parkingmanagementsys.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsys.exceptions.ParkingNotFoundException;

public interface Parkingslotdao {
	public Parkingslot create(Parkingslot parkslot) throws InvaliddetailId;
	public List<Parkingslot> findByid(int id) throws ParkingNotFoundException, SQLException;

}

