package com.cg.Labassignmenttwo.ui;

import java.util.Scanner;

import com.cg.Labassignmenttwo.dto.CalculateSumDiff;

public class Square {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		CalculateSumDiff diff=new CalculateSumDiff();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value of N natural number");
	
		int n=sc.nextInt();
		diff.calculateDifference(n);
		System.out.println(diff);
		
	}

}
