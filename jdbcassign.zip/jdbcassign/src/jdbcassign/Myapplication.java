package jdbcassign;

public class Myapplication {

	public static void main(String[] args) {
		Connection cc=new Connection();	

		
		
		
	}

}
