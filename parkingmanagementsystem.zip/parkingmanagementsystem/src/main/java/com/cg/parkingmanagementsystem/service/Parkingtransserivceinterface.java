package com.cg.parkingmanagementsystem.service;

import java.sql.SQLException;

import com.cg.parkingmanagementsystem.dto.Parktransaction;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsystem.exceptions.invaliddetailexcepion;

public interface Parkingtransserivceinterface {

	public void bookParking(Parktransaction parktrans) throws invaliddetailexcepion, InvaliddetailId, SQLException;
	
}
