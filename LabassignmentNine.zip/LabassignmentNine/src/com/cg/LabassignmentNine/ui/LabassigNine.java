package com.cg.LabassignmentNine.ui;

import java.util.Scanner;



public class LabassigNine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LabnineCla ni=new LabnineCla();
		  int n, c, d, swap,k,i;
		   
		    
		    Scanner in = new Scanner(System.in);
		 
		    System.out.println("enter the numbers you weant to sort");
		    n = in.nextInt();
		 
		    int array[] = new int[n];
		 
		    //System.out.println("Enter " + n + " integers");
		 
		    for (k = 0; k < n; k++) {
		      array[k] = in.nextInt();
		    }
		ni.getDataA(array);
		
		
		 System.out.println("Sorted list of numbers:");
		 
		
		 
		 
		 for (int z = 0; z < n; z++) {
		      System.out.println(array[z]);
		   
		    
		  }
		
	}

	
}
