package com.cg.Labexperminetfifte.ui;

import java.util.Scanner;

public class Labexperminetfifte {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("ENTER TGHE AGE");
	int i=sc.nextInt();
	
	try {
		if(i<15) {
			throw new personageexception("Sorry age is less than 15");
		}
		else {
			System.out.println("Person age is="+i);
		}
		
	}catch(personageexception e) {
	System.out.println(e.getMessage());	
	}
	
	

	}

}
	



