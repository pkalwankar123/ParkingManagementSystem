package com.cg.springmvcdemoone.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvcdemoone.dto.Product;
import com.cg.springmvcdemoone.service.Productserviceinterface;

@Controller
public class ProductConroller {
	
	@Autowired
	Productserviceinterface productservice;
	
//	@RequestMapping(value="login", method=RequestMethod.GET)
	@GetMapping("login")
	public  String loginPage() {
		return "mylogin";
		
	}
	
	@PostMapping("checklogin")
	public String doLogin(@RequestParam("uname") String user, @RequestParam("upass") String pass) {
	//	System.out.println("Check Login");
		if(user.equals("admin") && pass.equals("12345")){
			return "listpage";
		}
		else
		{
			return "error";
		}
		
	}

	
	@GetMapping("addpage")
	public ModelAndView getAddProduct(@ModelAttribute("prod") Product pro) {
		
		List <String> listOfcate=new ArrayList<>();
		listOfcate.add("Electronics");
		listOfcate.add("Grocery");
		listOfcate.add("Cloths");
		return new ModelAndView("addproduct","cato",listOfcate);
	}
	
	@GetMapping("showpage")
	public ModelAndView showProduct(@ModelAttribute("prod") Product pro) {
		List<Product> myallProduct=productservice.show();
		
		return new ModelAndView("showall","showproduct",myallProduct);
	}
	
	@PostMapping("addproduct")
	public ModelAndView addProduct(@ModelAttribute("prod") Product pro) {
		Product product=productservice.save(pro);
		return new ModelAndView("success","key",product);
	}
		
	
	
	
	
	
	
	}

	

