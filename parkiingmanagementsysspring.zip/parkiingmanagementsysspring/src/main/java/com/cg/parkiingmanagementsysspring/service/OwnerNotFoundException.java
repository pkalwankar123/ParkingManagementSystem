package com.cg.parkiingmanagementsysspring.service;

public class OwnerNotFoundException extends Exception {
	
	public OwnerNotFoundException() {
		
	}
	public OwnerNotFoundException(String msg) {
		super(msg);
	}

}
