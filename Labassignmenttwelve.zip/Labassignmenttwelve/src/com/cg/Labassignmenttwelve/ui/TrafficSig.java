package com.cg.Labassignmenttwelve.ui;

import java.util.Scanner;

public class TrafficSig {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i;
		Scanner sc=new Scanner(System.in);
		
		//System.out.println("");
		do{
			System.out.println("1. Red");
			System.out.println("2. Yellow");
			System.out.println("3. Green");
			System.out.println("4. Exit");
		i=sc.nextInt();
		switch(i){
			case 1:
				System.out.println("Stop");
				break;
			case 2:
				System.out.println("Go Slow");
				break;
			case 3:
				System.out.println("Ready");
				break;
			case 4:
				System.out.println("Thank you!!");
				System.exit(0);
				break;
			default:
				System.out.println("Invalid entry");
				break;
		}
	
		
		
		break;
	}while(i<4 );
		
	}

}
