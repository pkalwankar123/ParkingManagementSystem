package com.cg.LabassignSevan.ui;

import java.util.Scanner;

public class LabSevan {

	
	  public static void main(String []args) {
	    int n, c, d, swap,k,i;
	    SmallestNum sm=new SmallestNum();
	    
	    Scanner in = new Scanner(System.in);
	 
	    System.out.println("enter the numbers you weant to sort");
	    n = in.nextInt();
	 
	    int array[] = new int[n];
	 
	    //System.out.println("Enter " + n + " integers");
	 
	    for (k = 0; k < n; k++) {
	      array[k] = in.nextInt();
	    }
	   
	    sm.getsmallData(array);
	    
	   
	 
	    System.out.println("Sorted list of numbers:");
	 
	    for (int z = 0; z < n; z++) {
	      System.out.println(array[z]);
	   
	    
	  }
	  System.out.println("Smallest number from the list is"+"\t"+array[1]);
	}

}
 



