package com.cg.demospringannotation.ui;
import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.demospringannotation.config.JavaConfig;
import com.cg.demospringannotation.dto.Product;
import com.cg.demospringannotation.dto.Transaction;
import com.cg.demospringannotation.service.Productservice;


//@Component
public class Mytest {

/*@Autowired
Productservice service;
static Productservice productservice;
*/
//@PostConstruct
//public void init() {
 //productservice =this.service;
//}

static Product myProd;
public static void main(String[] args) {
 // TODO Auto-generated method stub
 
 AnnotationConfigApplicationContext app = new AnnotationConfigApplicationContext(JavaConfig.class);
 
 Product myProd = (Product) app.getBean("prod");
 Transaction myTran = (Transaction) app.getBean("tran");
 Productservice productservice = (Productservice) app.getBean("productservice");
 myProd.setId(101);
 myProd.setName("ASDF");
 myProd.setPrice(2622);
 myProd.setDescription("tetetet,.,.,");
 myTran.setId(1001);
 myTran.setAmount(5555.0);
 myTran.setDescription("jhghhjh..,,.,..");
//  myProd.getAllData();
//  System.out.println(myProd);
//  System.out.println(myTran);
//  ProductService productservice = new ProductServiceImpl();
 productservice.addProduct(myProd);
 System.out.println(productservice.showAll());
//  MyTest my = app.getBean(MyTest.class);
//  my.getData();
}

// public void getData() {
//  System.out.println("Sending "+ myProd);
//  productservice.addProduct(myProd);
//  System.out.println("Recieving "+ productservice.showAllProduct());
// }

}
