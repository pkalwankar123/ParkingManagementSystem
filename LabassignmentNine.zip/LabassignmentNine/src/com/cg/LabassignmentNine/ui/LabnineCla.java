package com.cg.LabassignmentNine.ui;

import java.util.Arrays;

public class LabnineCla {
	public void getDataA(int[] a) {
		//int temp=0;
		
		for(int i=a.length-1
				;i>=
				0;i--) {
		
			System.out.println(a[i]);
			
			
		}
		
		 Arrays.sort(a);
		
	//		
		
		
		//}	
	//int num=0;
		//while(a[i]>0) {
			//int num=a[i]%10;
		
			
		}
		
		
		
		
	}
	



