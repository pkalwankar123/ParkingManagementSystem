package com.cg.parkingmanagementsys.exceptions;

public class InvaliddetailId extends Exception {

public InvaliddetailId() {}
	
	public InvaliddetailId(String msg) {
		super(msg);
	}
	
	
}

