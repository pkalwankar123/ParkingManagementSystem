package com.cg.parkingmanagementsystem.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.parkingmanagementsystem.dto.Parkingslot;
import com.cg.parkingmanagementsystem.exceptions.InvalidOwnerId;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsystem.exceptions.ParkingNotFoundException;

public interface Parkingslotdao {
	public Parkingslot create(Parkingslot parkslot) throws InvaliddetailId, InvalidOwnerId;
	public List<Parkingslot> findByid(int id) throws ParkingNotFoundException, SQLException;

}

