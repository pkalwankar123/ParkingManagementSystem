package com.cg.parkiingmanagementsysspring.service;

import java.util.Date;

import com.cg.parkiingmanagementsysspring.dto.Parkingslot;

public interface Parkingslotinterface {

	public void createParkingslot(Parkingslot parkingslot);
	
	public  Parkingslot searchbydate(Date date);
	
}
