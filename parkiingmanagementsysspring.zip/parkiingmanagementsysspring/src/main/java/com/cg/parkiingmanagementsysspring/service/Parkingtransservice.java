package com.cg.parkiingmanagementsysspring.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.parkiingmanagementsysspring.dao.ParkingtransactionImpl;
import com.cg.parkiingmanagementsysspring.dto.Parktransaction;
import com.cg.parkiingmanagementsysspring.exceptions.invaliddetailexcepion;

@Service("parkingtransactionService")
public class Parkingtransservice implements Parkingtransserivceinterface{
	ParkingtransactionImpl parktrans;
	
	
	
@Autowired
	public void setParktrans(ParkingtransactionImpl parktrans) {
		this.parktrans = parktrans;
	}


	public void bookParking(Parktransaction parktrans1) throws invaliddetailexcepion{
		
		
		parktrans.book(parktrans1);
	}

}
