package com.cg.jpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.jpa.dto.Employee;
import com.cg.jpa.util.Dbutil;

public class EmpDaointerface implements EmpDaointerfacem{
EntityManager em;
	public EmpDaointerface() {
		em=Dbutil.getConnection();
	}
	
	
	public void save(Employee emp) {

		em.persist(emp);
		em.getTransaction().commit();
	}

	public List<Employee> findBySalary(double low, double higher) {
		Query query=em.createQuery("FROM Employee where sal  between :low and :high");
		query.setParameter("low", low);
		query.setParameter("high", higher);
		List<Employee> emplist=query.getResultList();
		
		
		return emplist;
	}

	public List<Employee> findByDeaprtmentname(String name) {
		
		
		Query query=em.createQuery("FROM Employee where dep.dep_name = :name");
		query.setParameter("name", name);
		List<Employee> emplist=query.getResultList();
		
		
		return emplist;
		
		
		
	}

}
