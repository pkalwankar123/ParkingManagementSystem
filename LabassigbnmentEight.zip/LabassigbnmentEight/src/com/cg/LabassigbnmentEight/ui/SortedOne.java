package com.cg.LabassigbnmentEight.ui;

import java.util.Arrays;

public class SortedOne {
	
public void getSortData(char[] array) {
	
	Arrays.sort(array);
	System.out.println();
	System.out.println(array);
	
	
}

}
