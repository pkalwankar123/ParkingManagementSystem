package com.cg.Labassignmentone.ui;

import java.util.Scanner;

import com.cg.Labassignmentone.dto.Firstlab;

public class Labone {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		Firstlab fb=new Firstlab();
		int j=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number");
		int n=sc.nextInt();
		fb.calculateSum(n);
		System.out.println(fb);

	}

}
;