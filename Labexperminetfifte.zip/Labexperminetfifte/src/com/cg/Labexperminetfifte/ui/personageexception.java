package com.cg.Labexperminetfifte.ui;

public class personageexception extends Exception {

	public personageexception() {}
	
	public personageexception(String msg) {
		super(msg);
	}
	
	
	
	
	
}
