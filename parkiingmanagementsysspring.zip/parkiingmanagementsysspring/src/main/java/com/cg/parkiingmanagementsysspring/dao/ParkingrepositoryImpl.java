package com.cg.parkiingmanagementsysspring.dao;

import org.springframework.stereotype.Repository;

import com.cg.parkiingmanagementsysspring.dto.Parking;
import com.cg.parkiingmanagementsysspring.util.DButil;

@Repository("parkingRepository")
public class ParkingrepositoryImpl implements Parkingrepositoryinterface{

	
	public Parking save(Parking park) {

		DButil.parking.add(park);
		
		return park;
	}

}