package com.cg.Labassignmentsixth.dto;

public class Book extends WrittenItem{
	
	private String addBook, addDescr, addAuthor;
	private int addPrice;
	
	public Book() {}
	
	public Book(String addBook, String addDescr, String addAuthor, int addPrice) {
		super();
		this.addBook = addBook;
		this.addDescr = addDescr;
		this.addAuthor = addAuthor;
		this.addPrice = addPrice;
		
	}
	
}
