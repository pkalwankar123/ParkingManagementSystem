package com.cg.parkingmanagementsys.dto;

public class Parking {
	//Attributes//
	private int id;
	private String Location;
	private Owner owner;
	
	//Constructors//
	public Parking (){}

	public Parking(int id, String location, Owner owner) {
		super();
		this.id = id;
		Location = location;
		this.owner = owner;
	}
	//Constructors//
	
	//Getter and setters//
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String location) {
		Location = location;
	}

	public Owner getOwner() {
		return owner;
	}

	public void setOwner(Owner owner) {
		this.owner = owner;
	}

	@Override
	public String toString() {
		return "parking [id=" + id + ", Location=" + Location + "]";
	}
	
}
