package com.cg.parkiingmanagementsysspring.dao;

import org.springframework.stereotype.Repository;

import com.cg.parkiingmanagementsysspring.dto.Owner;
import com.cg.parkiingmanagementsysspring.dto.Vehicle;
import com.cg.parkiingmanagementsysspring.exceptions.Duplicateaddressuserexception;
import com.cg.parkiingmanagementsysspring.util.DButil;


@Repository("ownerRepository")
public class OwnerrepositoryImpl implements Ownerdaorepositoryinterface{
	
	public Owner save(Owner owe){
DButil.owner.add(owe);
		
		return owe;
}
	
	

	public Owner findByID(int id) {

		
		for(Owner veh: DButil.owner){
			if(veh.getID()==id){
				return veh;
			}
		}
		
		
		return null;
	}
	

}
