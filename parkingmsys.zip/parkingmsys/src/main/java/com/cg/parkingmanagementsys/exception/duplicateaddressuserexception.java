package com.cg.parkingmanagementsys.exception;

public class duplicateaddressuserexception extends Exception {

	public duplicateaddressuserexception() {
		
	}
	public duplicateaddressuserexception(String msg) {
		super(msg);
	}
}
