package com.cg.parkiingmanagementsysspring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.parkiingmanagementsysspring.dao.Ownerdaorepositoryinterface;
import com.cg.parkiingmanagementsysspring.dto.Owner;
import com.cg.parkiingmanagementsysspring.dto.Vehicle;
import com.cg.parkiingmanagementsysspring.exceptions.VehicleNotFoundException;
@Service("ownerService")
public class OwnerserviceImpl implements Ownerserviceinterface{
 
	Ownerdaorepositoryinterface ownerDao;
	
@Autowired
	public void setOwnerDao(Ownerdaorepositoryinterface ownerDao) {
		this.ownerDao = ownerDao;
	}

	public void addOwner(Owner owner) {
		
		ownerDao.save(owner);
	}

public Owner searchbyId(int id) throws OwnerNotFoundException {
		
		if(ownerDao.findByID(id)==null){
			throw new OwnerNotFoundException("OOPS..Vehicle Not found into the Database."
					+ " Please enter the valid vehicle number and try again!!");
		
		}else
		
			return ownerDao.findByID(id);
	}
	
}
