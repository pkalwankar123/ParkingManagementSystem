package com.cg.springmvcdemoone.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvcdemoone.dao.Productdaointerface;
import com.cg.springmvcdemoone.dto.Product;
@Service
public class ProductserviceImpl implements  Productserviceinterface{

	@Autowired
	Productdaointerface productDao;
	
	
	@Override
	public Product save(Product product) {
		// TODO Auto-generated method stub
		return productDao.save(product);
	}

	@Override
	public List<Product> show() {
		// TODO Auto-generated method stub
		return productDao.show();
	}

}
