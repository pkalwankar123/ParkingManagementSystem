package com.cg.parkingmanagementsys.dao;

import com.cg.parkingmanagementsys.dto.Parkingslot;
import com.cg.parkingmanagementsys.util.DButil;

public class Parkingslotdaoclass implements Parkingslotdao{

	@Override
	public Parkingslot create(Parkingslot parkslot) {

		DButil.parkingslot.add(parkslot);
		
		return parkslot;
	}

}
