package com.cg.jpa.service;

import java.util.List;

import com.cg.jpa.dto.Employee;

public interface Employeeservice {

	
	public void addEmployee(Employee emp);
	public List<Employee> searchBySalary(double low,double higher);
	public List<Employee> searchByDeaprtmentname(String name);
}
