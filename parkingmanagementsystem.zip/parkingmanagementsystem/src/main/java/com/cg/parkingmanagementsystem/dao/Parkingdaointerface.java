package com.cg.parkingmanagementsystem.dao;

import com.cg.parkingmanagementsystem.dto.Parking;
import com.cg.parkingmanagementsystem.exceptions.InvalidOwnerId;
import com.cg.parkingmanagementsystem.exceptions.InvaliddetailId;

public interface Parkingdaointerface {

	public Parking save(Parking park) throws InvaliddetailId, InvalidOwnerId;
	


	
}
