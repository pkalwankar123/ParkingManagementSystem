package com.cg.parkiingmanagementsysspring.dao;

import com.cg.parkiingmanagementsysspring.dto.Vehicle;

public interface Vehiclerepositoryinterface {
public Vehicle save(Vehicle vehicle);
public Vehicle findByVehNo(String vehNo);

}
