package com.cg.Labassignmentfifth.ui;

import java.util.*;

public class ExcerLabFive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LabFive fiv=new LabFive();
		Scanner sc=new Scanner(System.in);
		System.out.println("Please enter the number that you want to check if it power of 2 or not");
		int n=sc.nextInt();
		
		if(fiv.LabVoidPower(n)==true) {
			System.out.println("Given number is power of two");
		}
		
		else {
			System.out.println("Given number is not power of two");
		}
	}

}
