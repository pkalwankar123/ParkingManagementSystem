package com.cg.parkiingmanagementsysspring.ui;

import java.math.BigInteger;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cg.parkiingmanagementsysspring.config.JavaConfig;
import com.cg.parkiingmanagementsysspring.dto.Address;
import com.cg.parkiingmanagementsysspring.dto.Owner;
import com.cg.parkiingmanagementsysspring.dto.Parking;
import com.cg.parkiingmanagementsysspring.dto.Parkingslot;
import com.cg.parkiingmanagementsysspring.dto.Parktransaction;
import com.cg.parkiingmanagementsysspring.dto.Vehicle;
import com.cg.parkiingmanagementsysspring.exceptions.VehicleNotFoundException;
import com.cg.parkiingmanagementsysspring.exceptions.invaliddetailexcepion;
import com.cg.parkiingmanagementsysspring.service.OwnerNotFoundException;
import com.cg.parkiingmanagementsysspring.service.Ownerserviceinterface;
import com.cg.parkiingmanagementsysspring.service.Parkingtransservice;
import com.cg.parkiingmanagementsysspring.service.VehicleServices;
import com.cg.parkiingmanagementsysspring.service.Vehicleservice;
import com.cg.parkiingmanagementsysspring.util.DButil;
//import com.cg.parkingmanagementsys.exception.InvaliddetailId;


public class Myapplication {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext appContext = new AnnotationConfigApplicationContext(JavaConfig.class);
	
		Owner owner=(Owner)appContext.getBean("owner");
		Ownerserviceinterface oweservice=(Ownerserviceinterface) appContext.getBean("ownerService");
		Vehicleservice vehservice=(Vehicleservice)appContext.getBean("vehicleService");
		Owner ownerOne=null;
		/*VehicleServices vehsservice=new VehicleServices();
		Parkingservice parkservice=new Parkingservice();
		Parkingslotservice parkslotservice=new Parkingslotservice();
		Parkingtransservice parktrans=new Parkingtransservice();*/
		
		int choice=0;
do{
		Scanner sc=new Scanner(System.in);
		System.out.println("================================================");
		System.out.println();
		System.out.println("========= Parking Management System ===========");
		System.out.println();
		System.out.println("================================================");
		System.out.println("=============== WELCOME ========================");
		System.out.println("1. Add Owner");
		System.out.println("2. Add Vehicles");
		System.out.println("3. Search Vehicles");
		System.out.println("4. Add Parking Location");
		System.out.println("5. Add Parkingslot");
		
		System.out.println("6. Assign Parking");
		System.out.println("7. Exit");
		System.out.println();
		System.out.println("================================================");
	
		choice=sc.nextInt();
		
		
		switch(choice){
		case 1: 
			System.out.println("Enter the ownerId");
			int ID=sc.nextInt();
			System.out.println("enter the name");
			String name=sc.next();
			System.out.println("enter the Mobile number");
			String mobNumber=sc.next();
			System.out.println("enter the house no");
			String houseno=sc.next();
			System.out.println("enter the Street");
			String street=sc.next();
			System.out.println("enter the city");
			String city=sc.next();
			System.out.println("enter the Pincode");
			int pincode=sc.nextInt();
			
			//address object for setting into owner
			Address address=(Address)appContext.getBean("address");
			
			
			owner.setID(ID);
			owner.setName(name);
			owner.setmobNumber(new BigInteger(mobNumber));
			address.setHouseNo(houseno);
			address.setStreet(street);
			address.setCity(city);
			address.setPincode(pincode);
			
			
			
				oweservice.addOwner(owner);
			
			
			System.out.println("================================");
			System.out.println();
			System.out.println("Owner Added successfully!!!!");
			System.out.println();
			System.out.println("=================================");
		
			
			
			
			for(Owner owe:DButil.owner){
										
				System.out.println(owe.getOwnerDetails());
				System.out.println("=================================");
			}
			
			
			break;	

		case 2: 
			char ch=0;
			
			System.out.println("enter owner ID");
			int oweid=sc.nextInt();
			
			do {
				Vehicle vehicle=(Vehicle)appContext.getBean("vehicle");
			System.out.println("enter vehicle number");
			String vehno=sc.next();
			System.out.println("enter vehicle desciption");
			String vedesc=sc.next();
						
					try {
						ownerOne=oweservice.searchbyId(oweid);
					} catch (OwnerNotFoundException e1) {
						System.out.println(e1.getMessage());
						break;
					}
					
					ownerOne.setID(oweid);
					vehicle.setOwner(owner);
					vehicle.setVehNo(vehno);
					vehicle.setVehDesc(vedesc);
					vehservice.add(vehicle);
			
				System.out.println("Do you want to assign another vehicle??  Y/N");
				ch=sc.next().charAt(0);
				System.out.println();
		}while(ch=='Y'||ch=='y');
		
					
			
					
					
		
				
				
			
			
				System.out.println("================================");
				System.out.println();
				System.out.println("Vehicles Added successfully!!!!");
				System.out.println();
				System.out.println("=================================");
				
				
				for(Vehicle owe:DButil.vehicle){
					
					System.out.println("Vehicle Number :- "+owe.getVehNo());
					System.out.println("Vehicle Description :- "+owe.getVehDesc());
				System.out.println("Owner detail related to vehicle :- "+owe.getOwner().getOwnerDetails());
				System.out.println("=================================");
				}
				
				break;
			
			
			
			
			
			/*case 3:
				System.out.println();
				System.out.println("=================================");
				System.out.println("Enter Vehicle number that you want too search");
				String vehNo=sc.next();
			Vehicle vehicle;
			try {
				vehicle = vehsservice.searchbyVehNo(vehNo);
				
				System.out.println("Here is your Vehicle detail...");
				System.out.println();
				System.out.println(vehicle.vehicleDetails());
				
			} catch (VehicleNotFoundException e) {
				
				System.out.println(e.getMessage());
			}
			System.out.println("=================================");
				break;
			case 4:
				System.out.println("=================================");
				parkservice.addParking(parking);
				
				System.out.println("Parking location Added successfullly!!!");
				System.out.println();
				for(Parking owe:DButil.parking){
					System.out.println("Parking id:- "+owe.getId());
					System.out.println("Parking Location:- "+owe.getLocation());
					
					
				System.out.println("Owner Detail:- "+owe.getOwner().getOwnerDetails());
				System.out.println("=================================");
				}
				break;
case 5:
	System.out.println("=================================");
	parkslotservice.createParkingslot(parkingslot);
	
				System.out.println("Parking slot created successfullly");
				System.out.println();
				for(Parkingslot owe:DButil.parkingslot){
					System.out.println("ParkingSlot ID:- "+owe.getId());
					System.out.println("Parkingslot for "+owe.getParking());
					System.out.print("ParkingSlot creator detail:- "+owe.getParking().getOwner().ownerDetails());
					System.out.println();
					System.out.println("Start date of parkingslot:- "+owe.getStartDate());
					System.out.println("End date of parkingslot:- "+owe.getEndDate());
					System.out.println("Start time of parkingslot:- "+owe.getStartTime());
					System.out.println("End time of parkingslot:- "+owe.getEndTime());						
					System.out.println();
					System.out.println("=================================");
				}
				break;
				

				
case 6:
			char ch;
			do {
		
	
	System.out.println("=================================");
	System.out.println();
	System.out.println("Enter parking id");
	int id=sc.nextInt();
	System.out.println();
	System.out.println("Enter Vehicle number");
	String vehNoone=sc.next();

	System.out.println("Enter time slot, start time in hrs and minutes:");
			System.out.println("eg. for 10:30 enter 10 hr then press 'Enter key' and enter the minutes 30 ");
	int pattern=sc.nextInt();

	
	int patterntwo=sc.nextInt();
	
	System.out.println("Till how many hrs you want to park vehicle");
	int patternOne=sc.nextInt();

	
	System.out.println();
	Vehicle vehicle1=new Vehicle();
	Parkingslot park=new Parkingslot();
	
	for(Vehicle vehic:DButil.vehicle){
		for(Parkingslot par:DButil.parkingslot){
			if((vehic.getVehNo().equals(vehNoone))&& (par.getId()==id)) {
				vehicle1=vehic;
				park=par;
				
						}
		}
	}
	try {
		if(vehicle1.getVehNo()==null || park.getId()!=id){
		throw new invaliddetailexcepion("OOPS!!..You have entered the wrong ID or Vehicle Number."
				+ "Please enter the valid detail and try again!!!");}
	} catch (invaliddetailexcepion e) {
		
		System.out.println(e.getMessage());
		break;
	}
		LocalTime startTime1 = LocalTime.of(pattern, patterntwo);
		LocalTime endTime1 = startTime1.plusHours(patternOne);
	
	
	
		
		LocalDate startDate1 = LocalDate.now();
		LocalDate endDate1 = LocalDate.now();


	Parktransaction parktranss=new Parktransaction(1,park,vehicle1,startDate1,endDate1,startTime1,endTime1);
	
	
	
			try {
				parktrans.bookParking(parktranss);
				
			} catch (invaliddetailexcepion e) {
				
				System.out.println(e.getMessage());
				break;
			}
				
				System.out.println("Parking assigned to below users successfullly..!!!");
				
				for(Parktransaction owe:DButil.parktrans){
					System.out.println("Parking transaction ID:- "+owe.getId());
					System.out.println(owe.getPk());
					System.out.print(owe.getVeh().vehicleDetails());
					System.out.println();
					System.out.println("Start date:- "+owe.getStartDate());
					System.out.println("End date:- "+owe.getEndDate());
					System.out.println("Start Time:- "+owe.getStartTime());
					System.out.println("End Time:- "+owe.getEndTime());
					System.out.println();			
				}
				System.out.println("================================================");
				
				System.out.println("Do you want to assign another vehicle??  Y/N");
				ch=sc.next().charAt(0);
				System.out.println();
		}while(ch=='Y'||ch=='y');
				break;
				
case 7:
	System.out.println("======= Thank you ======");
	System.exit(0);
			break;
			
			default:
				System.out.println("Oops..Invalid input."
						+ "Please enter the correct choice from the list!!!");
		*/}
	
	}while(choice!=6);

}}

