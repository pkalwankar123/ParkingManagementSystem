package com.cg.Labassignmentthree.ui;

public class InctreasingC {
	
	boolean b1=false;
	int dig=0,dig2=0;
	
	public boolean Increasingc(int n) {
		
		while(n>0) {
			dig=n%10;
			n /=10;
			dig2=n%10;
			if(dig > dig2) {
				
				b1=true;
				break;
			}
			else {
				break;
			}
			
			
		}
		return b1;
		
		
	
		
		
		}

	@Override
	public String toString() {
		return "InctreasingC b1=" + b1;
	}
		
		
		
		
	


}
