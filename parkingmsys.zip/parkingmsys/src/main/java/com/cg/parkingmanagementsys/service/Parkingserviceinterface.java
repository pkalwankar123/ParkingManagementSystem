package com.cg.parkingmanagementsys.service;

import com.cg.parkingmanagementsys.dto.Parking;
import com.cg.parkingmanagementsys.exceptions.InvaliddetailId;

public interface Parkingserviceinterface {

	public void addParking(Parking parking) throws InvaliddetailId;
	
}
