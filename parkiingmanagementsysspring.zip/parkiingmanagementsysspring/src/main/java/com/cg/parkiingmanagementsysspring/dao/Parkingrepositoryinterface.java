package com.cg.parkiingmanagementsysspring.dao;

import com.cg.parkiingmanagementsysspring.dto.Parking;

public interface Parkingrepositoryinterface {

	public Parking save(Parking park);
	
}
