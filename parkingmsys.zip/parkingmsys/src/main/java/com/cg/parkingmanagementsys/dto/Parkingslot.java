package com.cg.parkingmanagementsys.dto;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;



public class Parkingslot {
	//Attributes//
	private int id;
	private Parking parking;
	
	
	
	private LocalDate startDate;
	private LocalDate endDate;
	
	private LocalTime startTime;
	
	private LocalTime endTime;

	//Constructors//
	public Parkingslot(){}
	public Parkingslot(int id, Parking parking, LocalDate startDate, LocalDate endDate,LocalTime startTime, LocalTime endTime) {
		super();
		this.id = id;
		this.parking = parking;
		this.startDate = startDate;
		this.endDate = endDate;
		this.startTime = startTime;
		this.endTime = endTime;
	}
	
	//Getter and setters//
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Parking getParking() {
		return parking;
	}
	public void setParking(Parking parking) {
		this.parking = parking;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	
	public LocalTime getStartTime() {
		return startTime;
	}
	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}
	public LocalTime getEndTime() {
		return endTime;
	}
	public void setEndTime(LocalTime endTime) {
		this.endTime = endTime;
	}
	@Override
	public String toString() {
		return "Parkingslot [id=" + id + ", parking=" + parking + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", startTime=" + startTime + ", endTime=" + endTime + "]";
	}
		
	
	
	
}
