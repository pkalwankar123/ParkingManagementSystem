package com.cg.LabAssignmentten.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Checked {
	public void getData() throws IOException{
	 int count=0,len=0;
	 String ch;
	 BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	 ch=br.readLine();
     do
     {  
       try
       {
       char name[]=ch.toCharArray();
           len=name.length;
           count=0;
           for(int j=0;j<len;j++)
            {
               if((name[0]==name[j])) 
                   count++;
            }
           if(count!=0)
             System.out.println(name[0]+" "+count+" Times");
           ch=ch.replace(""+name[0],"");          
       }
       catch(Exception ex){}
     }
     while(len!=1);

}
}