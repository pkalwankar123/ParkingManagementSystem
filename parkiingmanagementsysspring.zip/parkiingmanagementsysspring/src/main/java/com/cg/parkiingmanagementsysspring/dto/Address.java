package com.cg.parkiingmanagementsysspring.dto;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("address")
public class Address {
public Address(String houseNo, String street, String city, int pincode) {
		super();
		this.houseNo = houseNo;
		Street = street;
		this.city = city;
		this.pincode = pincode;
	}
private String houseNo;
private String Street;
private String city;
private int pincode;
public Address() {}
public String getHouseNo() {
	return houseNo;
}
public void setHouseNo(String houseNo) {
	this.houseNo = houseNo;
}
public String getStreet() {
	return Street;
}
public void setStreet(String street) {
	Street = street;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public int getPincode() {
	return pincode;
}
public void setPincode(int pincode) {
	this.pincode = pincode;
}
@Override
public String toString() {
	return "Address [houseNo=" + houseNo + ", Street=" + Street + ", city=" + city + ", pincode=" + pincode + "]";
}



}
