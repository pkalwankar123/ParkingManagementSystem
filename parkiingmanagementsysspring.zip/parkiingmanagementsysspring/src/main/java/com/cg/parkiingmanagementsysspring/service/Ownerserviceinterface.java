package com.cg.parkiingmanagementsysspring.service;

import com.cg.parkiingmanagementsysspring.dto.Owner;
import com.cg.parkiingmanagementsysspring.dto.Parking;

public interface Ownerserviceinterface {
	public void addOwner(Owner owner);
	public Owner searchbyId(int id) throws OwnerNotFoundException;
}
