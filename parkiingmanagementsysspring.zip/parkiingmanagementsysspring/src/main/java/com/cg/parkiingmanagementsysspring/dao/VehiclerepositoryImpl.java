package com.cg.parkiingmanagementsysspring.dao;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.cg.parkiingmanagementsysspring.dto.Vehicle;
import com.cg.parkiingmanagementsysspring.util.DButil;

@Repository("vehicleRepository")
public class VehiclerepositoryImpl implements Vehiclerepositoryinterface{

	
	
	

	public Vehicle save(Vehicle vehicle) {
	
		

DButil.vehicle.add(vehicle);

		
		return vehicle;
	}


	public Vehicle findByVehNo(String vehNo) {

		
		for(Vehicle veh: DButil.vehicle){
			if(veh.getVehNo().equals(vehNo)){
				return veh;
			}
		}
		
		
		return null;
	}
	

}