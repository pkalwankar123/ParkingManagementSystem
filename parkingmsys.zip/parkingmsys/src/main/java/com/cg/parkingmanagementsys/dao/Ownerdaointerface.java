package com.cg.parkingmanagementsys.dao;

import java.sql.SQLException;

import com.cg.parkingmanagementsys.dto.Owner;
import com.cg.parkingmanagementsys.exception.duplicateaddressuserexception;
import com.cg.parkingmanagementsys.exceptions.Duplicateaddressuserexception;

public interface Ownerdaointerface {

	public Owner save(Owner owner) throws  Duplicateaddressuserexception, SQLException;
	
	
}
