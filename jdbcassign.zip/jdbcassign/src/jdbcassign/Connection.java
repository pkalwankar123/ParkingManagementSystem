package jdbcassign;

public class Connection {

}
