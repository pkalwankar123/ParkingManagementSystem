package com.cg.LabassigbnmentEight.ui;

import java.util.Scanner;

public class UppercaseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SortedOne sd=new SortedOne();
		int z1=0;
		Scanner scr=new Scanner(System.in);
		System.out.println("enter the string that you want to check");
		char array[]=scr.next().toCharArray();	
		
	
				
				for(int c=0;c<array.length;c++) {
					System.out.print(array[c]);
					//char array[c]=scr.next().toCharArray();	
		
	}
				
		sd.getSortData(array);
		
		
		int a=array.length;
		if(a%2==0) {
			z1=a/2;	
		}
		else {
			z1=a/2+1;
		}
		
		
		//System.out.println(a);
	for(int k=0;k<z1;k++) {
		
		//char[] ch = null;
		//int i = 0;
		array[k] = (char)(array[k] + 'A' - 'a'); 
		
	
	}
	System.out.println(array);
	
}	
}
