package com.cg.ServletApplicationDemo1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class preview
 */
@WebServlet("/preview")
public class preview extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public preview() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);

String guestname=request.getParameter("guestname");
String email=request.getParameter("email");
		
		response.setContentType("text/html");
		
		PrintWriter out=response.getWriter();
		

		out.println("<html>");
		out.println("<head>");
		out.println("<title>Svaed Data!!!</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<h2>Welcome!!</h2>");
		//out.println("<p> Error Status code"++"</p>");
		out.println("<p> guest "+guestname+"</p>");
		out.println("<p> email "+email+"</p>");
		out.println("<form name='fm1' action='savedata' method='post'>");
		
		out.println("<input type='hidden' name='guestname' value='"+guestname+"'/>");
		out.println("<input type='hidden' name='email' value='"+email+"'/>");
			out.println("<p><input type='submit' name='Submit' value='button'/></p>");
		out.println("</form>");
		
		
		out.println("</body>");
		out.println("</html>");
	}

}
