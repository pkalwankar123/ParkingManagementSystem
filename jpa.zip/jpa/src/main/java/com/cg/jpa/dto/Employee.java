package com.cg.jpa.dto;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="employeedb")
public class Employee {


	public Employee() {
		
		
		
	}
	@Id
	@Column(name="emp_id")
	private int id;
	@Column(name="emp_name")
	
	private String name;
	
	@Column(name="emp_sal")
	
	private double sal;
	@Column(name="emp_type")
	private boolean type;
	
	@Column(name= "emp_dateofjoining")
	@Temporal(TemporalType.TIME)
	private Date dateofjoining;
	
	
	
	
	
	@Embedded
	private Address add;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="dep_id")
	private Department dep;
	/*
	public Employee(int id, String name, double sal, boolean type, Date dateofjoining, Address add) {
		super();
		this.id = id;
		this.name = name;
		this.sal = sal;
		this.type = type;
		this.dateofjoining = dateofjoining;
		this.add = add;
		//this.dep = dep;
	}

*/
	
	
	
	public Date getDateofjoining() {
		return dateofjoining;
	}


	public Employee(int id, String name, double sal, boolean type, Date dateofjoining, Address add, Department dep) {
		super();
		this.id = id;
		this.name = name;
		this.sal = sal;
		this.type = type;
		this.dateofjoining = dateofjoining;
		this.add = add;
		this.dep = dep;
	}


	public void setDateofjoining(Date dateofjoining) {
		this.dateofjoining = dateofjoining;
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	public boolean isType() {
		return type;
	}
	public void setType(boolean type) {
		this.type = type;
	}


	public Address getAdd() {
		return add;
	}


	public void setAdd(Address add) {
		this.add = add;
	}


	public Department getDep() {
		return dep;
	}





	public void setDep(Department dep) {
		this.dep = dep;
	}


	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", sal=" + sal + ", type=" + type + ", dateofjoining="
				+ dateofjoining + ", add=" + add + ", dep=" + dep + "]";
	}





	







	
	
	
}
