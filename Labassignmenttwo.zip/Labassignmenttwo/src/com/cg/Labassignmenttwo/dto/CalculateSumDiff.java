package com.cg.Labassignmenttwo.dto;

public class CalculateSumDiff {
	
	
	int sum=0, sqrsum=0,diffe=0,sqrsum1=0;
	
	
	public int calculateDifference(int n) {
		
		for(int j=0;j<=n;j++) {
			if(n>0) {
				//first adding the n Natural numbers and produce the Square
				
				sum +=j;
				if(j==n) {
					sum *=sum;
					System.out.println("sqaure of sum of n natural number"+sum);
				}
				
			// Adding the first N Natural numbers Square
				sqrsum= j*j;
				sqrsum1 += sqrsum;
				if(j==n) {
					
					System.out.println("square of N natural number and summing all of them"+sqrsum1);
				
				}
			}
			
		}
		
		
		

		
		return diffe=sum-sqrsum1;
		
	}


	@Override
	public String toString() {
		return "difference between sqaure of sum of n natural number and square of N natural number=" + diffe;
	}

}
