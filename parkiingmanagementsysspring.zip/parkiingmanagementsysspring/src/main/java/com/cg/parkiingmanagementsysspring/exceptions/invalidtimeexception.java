package com.cg.parkiingmanagementsysspring.exceptions;

public class invalidtimeexception extends Exception {

	public invalidtimeexception(){}
	
	public invalidtimeexception(String message){
		super(message);
	}
}
