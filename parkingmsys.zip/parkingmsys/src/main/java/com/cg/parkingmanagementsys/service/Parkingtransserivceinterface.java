package com.cg.parkingmanagementsys.service;

import java.sql.SQLException;

import com.cg.parkingmanagementsys.dto.Parktransaction;
import com.cg.parkingmanagementsys.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsys.exceptions.invaliddetailexcepion;

public interface Parkingtransserivceinterface {

	public void bookParking(Parktransaction parktrans) throws invaliddetailexcepion, InvaliddetailId, SQLException;
	
}
