package com.cg.Labassignmentfourteen.ui;

import java.util.Scanner;

public class Labassignmentfourteen {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	
	//System.out.println("Please enter the first name");
	//String firstname=sc.next();
	//System.out.println("Please enter the last name");
	//String lastname=sc.next();
	
	
	
	String firstName="Pradip";
	String lastName="";

	
	String fullname=firstName+lastName;
	
	try {
		
		if(firstName.isEmpty() || lastName.isEmpty()) {
		
			throw new firstlastnameexception("Please enter the username or lastname");
			
			
			
		}
	
		else {
			System.out.println(fullname);
		}
			
	}catch(firstlastnameexception e) {
		System.out.println(e.getMessage());
	}
		

	}

}
