package com.cg.springmvcdemoone.dao;

import java.util.List;

import com.cg.springmvcdemoone.dto.Product;

public interface Productdaointerface {
public Product save(Product product);
public List<Product> show();
}
