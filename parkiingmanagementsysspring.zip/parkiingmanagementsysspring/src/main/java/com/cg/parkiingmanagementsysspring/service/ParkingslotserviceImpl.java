package com.cg.parkiingmanagementsysspring.service;

import java.util.Date;


import com.cg.parkiingmanagementsysspring.dao.ParkingslotrepositoryImpl;
import com.cg.parkiingmanagementsysspring.dto.Parkingslot;

public class ParkingslotserviceImpl implements Parkingslotinterface{

	ParkingslotrepositoryImpl parkslot;
	
	public ParkingslotserviceImpl(){
		parkslot=new ParkingslotrepositoryImpl();
	}
	
	
	public void createParkingslot(Parkingslot parkingslot) {

		parkslot.create(parkingslot);
	}


	public Parkingslot searchbydate(Date date) {

		return null;
	}

}

