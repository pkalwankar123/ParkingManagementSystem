package com.cg.springmvcdemoone.service;

import java.util.List;

import com.cg.springmvcdemoone.dto.Product;

public interface Productserviceinterface {
	public Product save(Product product);
	public List<Product> show();
}
