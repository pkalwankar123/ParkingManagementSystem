package com.cg.parkingmanagementsystem.dao;

import java.sql.SQLException;

import com.cg.parkingmanagementsystem.dto.Owner;
import com.cg.parkingmanagementsystem.exceptions.Duplicateaddressuserexception;

public interface Ownerrepositoryinterface {

	public Owner save(Owner owner) throws  Duplicateaddressuserexception, SQLException;
	
	
}
