package com.cg.parkingmanagementsys.service;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import com.cg.parkingmanagementsys.dao.Parkingslotdaoclass;
import com.cg.parkingmanagementsys.dto.Parkingslot;
import com.cg.parkingmanagementsys.exceptions.InvaliddetailId;
import com.cg.parkingmanagementsys.exceptions.ParkingNotFoundException;

public class Parkingslotservice implements Parkingslotinterface{


	Parkingslotdaoclass parkslot;
	
	public Parkingslotservice(){
		parkslot=new Parkingslotdaoclass();
	}
	
	
	public void createParkingslot(Parkingslot parkingslot) throws InvaliddetailId {
		// TODO Auto-generated method stub
		parkslot.create(parkingslot);
	}
	
	public List<Parkingslot> searchByid(int id) throws ParkingNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return parkslot.findByid(id);
	}

}

