package com.cg.parkiingmanagementsysspring.service;

import com.cg.parkiingmanagementsysspring.dto.Parktransaction;
import com.cg.parkiingmanagementsysspring.exceptions.invaliddetailexcepion;

public interface Parkingtransserivceinterface {

	public void bookParking(Parktransaction parktrans) throws invaliddetailexcepion;
	
}
