package com.cg.parkingmanagementsys.exception;

public class InvaliddetailId extends Exception {

	public InvaliddetailId() {}
	
	public InvaliddetailId(String msg) {
		super(msg);
	}
	
	
}
