package com.cg.Labassignseventeen.ui;

public class Mystring {

	public static void main(String[] args) {
		

	}

}
