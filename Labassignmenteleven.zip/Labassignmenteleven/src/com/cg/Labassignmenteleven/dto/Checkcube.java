package com.cg.Labassignmenteleven.dto;

public class Checkcube {
int sum=0,i;
int res=0;
	public void getData(int[] digit1) {
	
		for(int a:digit1) {
			sum=a*a*a;
			res=res+sum;
		}
		System.out.println(res);
		
		
		
	
	}
	
}
