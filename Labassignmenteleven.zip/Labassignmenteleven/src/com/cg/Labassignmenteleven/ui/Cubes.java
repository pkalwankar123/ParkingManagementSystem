package com.cg.Labassignmenteleven.ui;

import java.util.Scanner;

import com.cg.Labassignmenteleven.dto.Checkcube;

public class Cubes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Checkcube cb=new Checkcube();
		int num;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		num=sc.nextInt();
		
		int[] digit1=new int[num];
		
		for(int k=0;k<num;k++) {
			
			digit1[k]=sc.nextInt();
		}
		
		
		
		cb.getData(digit1);
		
	}

}
